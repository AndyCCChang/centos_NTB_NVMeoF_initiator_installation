#!/usr/bin/env bash
sudo -H pip install NVME_Wheel*